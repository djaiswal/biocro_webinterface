<?php

$graph_variables=array("DAP","Leaf","Stem","Root","Sugar","LAI","ThermalT");
// Spaces are not allowed in variable names.

?>
