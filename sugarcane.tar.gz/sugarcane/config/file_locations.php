<?php

// This is the XML file to be created.
$new_xml_file="./data.xml";

// This file defines and structure of the XML file.
$xml_structure_file="config/xml_structure.txt";

// This is the XML file to read the default values from.
$default_xml="./default/default.xml";

//This shell script will be executed when the  "Run" button is clicked.
$sh_file="./run.sh";

?>
